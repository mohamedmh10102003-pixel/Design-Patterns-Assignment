# Design Patterns Assignment - E-Commerce Order Management System

Language: Java 17

Implemented design patterns:
1. Singleton - AppConfig
2. Factory Method - PaymentProcessorFactory
3. Observer - Order / OrderObserver / Customer

## Run
```bash
javac -d out $(find src -name "*.java")
java -cp out com.example.designpatterns.Main
```

If your system does not support `find`, compile all `.java` files under `src/main/java` using your IDE.

## GitHub
Create a GitHub repository and upload this project. Then replace the GitHub placeholder in the PDF report with your repository URL.
