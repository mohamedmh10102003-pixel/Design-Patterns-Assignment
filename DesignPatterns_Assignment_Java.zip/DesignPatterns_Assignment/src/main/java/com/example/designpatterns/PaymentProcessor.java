package com.example.designpatterns;

public interface PaymentProcessor {
    boolean pay(double amount);
    String getName();
}
