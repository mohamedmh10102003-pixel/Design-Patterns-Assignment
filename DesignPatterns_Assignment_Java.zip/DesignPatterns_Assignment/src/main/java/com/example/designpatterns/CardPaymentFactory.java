package com.example.designpatterns;

public class CardPaymentFactory extends PaymentProcessorFactory {
    @Override
    public PaymentProcessor createProcessor() {
        return new CardPaymentProcessor();
    }
}
