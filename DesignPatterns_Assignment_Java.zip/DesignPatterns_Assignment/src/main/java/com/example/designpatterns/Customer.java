package com.example.designpatterns;

public class Customer implements OrderObserver {
    private final String name;

    public Customer(String name) {
        this.name = name;
    }

    @Override
    public void update(Order order) {
        System.out.println("Notification for " + name +
                ": Order #" + order.getId() +
                " status changed to " + order.getStatus());
    }
}
