package com.example.designpatterns;

public interface OrderObserver {
    void update(Order order);
}
