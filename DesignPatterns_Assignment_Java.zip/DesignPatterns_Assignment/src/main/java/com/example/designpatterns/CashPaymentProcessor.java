package com.example.designpatterns;

public class CashPaymentProcessor implements PaymentProcessor {
    @Override
    public boolean pay(double amount) {
        Logger.getInstance().info("Cash payment received: " + amount + " " +
                AppConfig.getInstance().getCurrency());
        return true;
    }

    @Override
    public String getName() {
        return "Cash";
    }
}
