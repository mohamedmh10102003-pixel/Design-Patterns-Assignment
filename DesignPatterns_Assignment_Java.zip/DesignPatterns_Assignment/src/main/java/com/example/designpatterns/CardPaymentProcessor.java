package com.example.designpatterns;

public class CardPaymentProcessor implements PaymentProcessor {
    @Override
    public boolean pay(double amount) {
        Logger.getInstance().info("Card payment processed: " + amount + " " +
                AppConfig.getInstance().getCurrency());
        return true;
    }

    @Override
    public String getName() {
        return "Card";
    }
}
