package com.example.designpatterns;

import java.util.ArrayList;
import java.util.List;

/**
 * Observer Subject: notifies all registered observers whenever order status changes.
 */
public class Order {
    public enum Status {
        CREATED, PAID, SHIPPED, DELIVERED
    }

    private final int id;
    private final double total;
    private Status status;
    private final List<OrderObserver> observers = new ArrayList<>();

    public Order(int id, double total) {
        this.id = id;
        this.total = total;
        this.status = Status.CREATED;
    }

    public void addObserver(OrderObserver observer) {
        if (observer != null && !observers.contains(observer)) {
            observers.add(observer);
        }
    }

    public void removeObserver(OrderObserver observer) {
        observers.remove(observer);
    }

    public void setStatus(Status newStatus) {
        if (newStatus == null || newStatus == status) {
            return;
        }
        status = newStatus;
        notifyObservers();
    }

    private void notifyObservers() {
        for (OrderObserver observer : List.copyOf(observers)) {
            observer.update(this);
        }
    }

    public int getId() {
        return id;
    }

    public double getTotal() {
        return total;
    }

    public Status getStatus() {
        return status;
    }
}
