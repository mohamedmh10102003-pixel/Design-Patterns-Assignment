package com.example.designpatterns;

public class Main {
    public static void main(String[] args) {
        AppConfig config = AppConfig.getInstance();
        Logger.getInstance().info("Starting " + config.getApplicationName());

        Order order = new Order(1001, 2500.00);

        Customer customer = new Customer("Mohamed");
        order.addObserver(customer);

        OrderService service = new OrderService();

        // Factory Method chooses the payment implementation.
        PaymentProcessorFactory paymentFactory = new CardPaymentFactory();
        service.payOrder(order, paymentFactory);

        service.shipOrder(order);
        service.deliverOrder(order);

        // Demonstrate that Singleton returns the same shared instance.
        AppConfig anotherConfigReference = AppConfig.getInstance();
        System.out.println("Same AppConfig instance? " +
                (config == anotherConfigReference));

        Logger.getInstance().info("Program finished successfully.");
    }
}
