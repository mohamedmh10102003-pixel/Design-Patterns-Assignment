package com.example.designpatterns;

public class OrderService {

    public void payOrder(Order order, PaymentProcessorFactory factory) {
        if (factory.processPayment(order.getTotal())) {
            order.setStatus(Order.Status.PAID);
        }
    }

    public void shipOrder(Order order) {
        order.setStatus(Order.Status.SHIPPED);
    }

    public void deliverOrder(Order order) {
        order.setStatus(Order.Status.DELIVERED);
    }
}
