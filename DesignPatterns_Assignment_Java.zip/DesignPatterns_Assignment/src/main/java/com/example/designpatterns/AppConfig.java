package com.example.designpatterns;

/**
 * Singleton: stores application-wide configuration.
 * The class has one shared instance throughout the application.
 */
public final class AppConfig {
    private static volatile AppConfig instance;

    private final String applicationName;
    private final String currency;

    private AppConfig() {
        applicationName = "SmartShop Order Management";
        currency = "EGP";
    }

    public static AppConfig getInstance() {
        if (instance == null) {
            synchronized (AppConfig.class) {
                if (instance == null) {
                    instance = new AppConfig();
                }
            }
        }
        return instance;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public String getCurrency() {
        return currency;
    }
}
