package com.example.designpatterns;

/**
 * Factory Method: subclasses decide which PaymentProcessor to create.
 */
public abstract class PaymentProcessorFactory {

    public abstract PaymentProcessor createProcessor();

    public boolean processPayment(double amount) {
        PaymentProcessor processor = createProcessor();
        Logger.getInstance().info("Using " + processor.getName() + " payment.");
        return processor.pay(amount);
    }
}
