package com.example.designpatterns;

public class CashPaymentFactory extends PaymentProcessorFactory {
    @Override
    public PaymentProcessor createProcessor() {
        return new CashPaymentProcessor();
    }
}
